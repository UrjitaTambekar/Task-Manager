import Column from "./Column";

const statuses = [
  "Todo",
  "Progress",
  "Done",
];

const Board = ({ tasks }) => {
  return (
    <div className="board">

      {statuses.map((status) => (
        <Column
          key={status}
          status={status}
          tasks={tasks}
        />
      ))}

    </div>
  );
};

export default Board;